package br.edu.inatel.soa.bmi.soap;

public class BMIServiceProxy implements br.edu.inatel.soa.bmi.soap.BMIService {
  private String _endpoint = null;
  private br.edu.inatel.soa.bmi.soap.BMIService bMIService = null;
  
  public BMIServiceProxy() {
    _initBMIServiceProxy();
  }
  
  public BMIServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initBMIServiceProxy();
  }
  
  private void _initBMIServiceProxy() {
    try {
      bMIService = (new br.edu.inatel.soa.bmi.soap.BMIServiceServiceLocator()).getBMIService();
      if (bMIService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)bMIService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)bMIService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (bMIService != null)
      ((javax.xml.rpc.Stub)bMIService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.edu.inatel.soa.bmi.soap.BMIService getBMIService() {
    if (bMIService == null)
      _initBMIServiceProxy();
    return bMIService;
  }
  
  public br.edu.inatel.soa.bmi.soap.BMIResult getBMI(float weight, float height, java.lang.String lang) throws java.rmi.RemoteException{
    if (bMIService == null)
      _initBMIServiceProxy();
    return bMIService.getBMI(weight, height, lang);
  }
  
  
}