package br.edu.inatel.soa.bmi.runner;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.edu.inatel.soa.bmi.soap.BMIResult;
import br.edu.inatel.soa.bmi.soap.BMIServiceProxy;

 /* O �ndice de Massa Corporal representada pela sigla IMC 
  � a medida do grau de obesidade de uma pessoa, considerando
  a altura e a massa de uma pessoa.*/

public class IMC extends JPanel {
    
    // Autor: Jo�o Matheus Santos Assis
    
    float Mass_a, Altur_a, Resultad_o;
    
    private JPanel Obter_dados = new JPanel();
    private JPanel Exibir_Resultado = new JPanel();

    private JLabel Exibi_IMC = new JLabel();
    private JLabel EXibi_Status = new JLabel();
    
    // Espera-se que a massa esteja em quilogramas e a altura em metros.
    private JLabel Massa = new JLabel("Massa (Kg): ");
    private JLabel Altura = new JLabel(" Altura (m): ");

    private JTextField M_assa = new JTextField(9);
    private JTextField A_ltura = new JTextField(9);

    private JButton Calcular = new JButton("Calcular");
    private JButton Limpar = new JButton("Limpar");

    public IMC(){
        
        // Definindo a fonte dos JLabel's
        Massa.setFont(new Font("Tahoma", Font.BOLD, 14));
        Altura.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        
        // Adicionando os componentes
        Obter_dados.add(Massa);
        Obter_dados.add(M_assa);
        Obter_dados.add(Altura);
        Obter_dados.add(A_ltura);
        Obter_dados.add(Calcular);
        Obter_dados.add(Limpar);
        Obter_dados.add(Exibi_IMC);

        add(Obter_dados);
        // Adicionando t�tulo ao JLabel
        Obter_dados.setBorder(BorderFactory.createTitledBorder("IMC"));
        // Dimens�o do JPanel 210 de comprimento por 150 de largura
        Obter_dados.setPreferredSize(new Dimension(210,150));
        
        Exibir_Resultado.add(EXibi_Status);
        
        add(Exibir_Resultado);
        Exibir_Resultado.setBorder(BorderFactory.createTitledBorder("Resultado"));
        Exibir_Resultado.setPreferredSize(new Dimension(210,90));
        
        
        Calcular.addActionListener(new ActionListener(){
            
            public void actionPerformed( ActionEvent event){
            
            // Obtendo a massa e a altura e convertendo de String para float
            Mass_a = Float.valueOf(M_assa.getText());
            Altur_a = Float.valueOf(A_ltura.getText());
            
            BMIServiceProxy bmiService = new BMIServiceProxy();
            try {
				BMIResult bmiResult = bmiService.getBMI(Mass_a, Altur_a, "");
				EXibi_Status.setText(String.valueOf(bmiResult.getBmi()));
				Exibi_IMC.setText(String.valueOf(bmiResult.getDescription())); 
			} 
            catch (RemoteException e) {
            	JOptionPane.showMessageDialog(null,"Servi�o n�o dispon�vel no momento!");
			}
                        
            
            
            }});
            
            
            Limpar.addActionListener(new ActionListener(){
                
            public void actionPerformed(ActionEvent event){
                
                // Apagando os conte�dos os JTextField's'
                M_assa.setText("");
                A_ltura.setText("");
                Exibi_IMC.setText("");
            
            }                
            });
        
    }

    public static void main(String[] args){
        
        JFrame Janela = new JFrame();
        IMC imc = new IMC();
        
        Janela.add(imc);
        
        Janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Janela.setTitle("Calculando o IMC");
        Janela.setSize(240,300);
        Janela.setVisible(true);
        Janela.setResizable(false);
        Janela.setLocationRelativeTo(null);
    }
}
