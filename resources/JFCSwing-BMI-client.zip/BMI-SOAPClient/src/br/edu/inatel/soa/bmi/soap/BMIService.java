/**
 * BMIService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.edu.inatel.soa.bmi.soap;

public interface BMIService extends java.rmi.Remote {
    public br.edu.inatel.soa.bmi.soap.BMIResult getBMI(float weight, float height, java.lang.String lang) throws java.rmi.RemoteException;
}
