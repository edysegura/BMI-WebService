/**
 * BMIServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.edu.inatel.soa.bmi.soap;

public class BMIServiceServiceLocator extends org.apache.axis.client.Service implements br.edu.inatel.soa.bmi.soap.BMIServiceService {

    public BMIServiceServiceLocator() {
    }


    public BMIServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public BMIServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BMIService
    private java.lang.String BMIService_address = "http://bmi-webservice.elasticbeanstalk.com/services/BMIService";

    public java.lang.String getBMIServiceAddress() {
        return BMIService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BMIServiceWSDDServiceName = "BMIService";

    public java.lang.String getBMIServiceWSDDServiceName() {
        return BMIServiceWSDDServiceName;
    }

    public void setBMIServiceWSDDServiceName(java.lang.String name) {
        BMIServiceWSDDServiceName = name;
    }

    public br.edu.inatel.soa.bmi.soap.BMIService getBMIService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BMIService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBMIService(endpoint);
    }

    public br.edu.inatel.soa.bmi.soap.BMIService getBMIService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            br.edu.inatel.soa.bmi.soap.BMIServiceSoapBindingStub _stub = new br.edu.inatel.soa.bmi.soap.BMIServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getBMIServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBMIServiceEndpointAddress(java.lang.String address) {
        BMIService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.edu.inatel.soa.bmi.soap.BMIService.class.isAssignableFrom(serviceEndpointInterface)) {
                br.edu.inatel.soa.bmi.soap.BMIServiceSoapBindingStub _stub = new br.edu.inatel.soa.bmi.soap.BMIServiceSoapBindingStub(new java.net.URL(BMIService_address), this);
                _stub.setPortName(getBMIServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BMIService".equals(inputPortName)) {
            return getBMIService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://soap.bmi.soa.inatel.edu.br", "BMIServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://soap.bmi.soa.inatel.edu.br", "BMIService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BMIService".equals(portName)) {
            setBMIServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
