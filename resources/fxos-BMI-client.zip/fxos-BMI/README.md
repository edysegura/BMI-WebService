fxos-BMI
========

A FxOS App to calculate the BMI - Body Mass Index
