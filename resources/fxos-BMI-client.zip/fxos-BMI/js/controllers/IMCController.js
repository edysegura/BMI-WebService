
function IMCController($scope, $http) {
	$scope.result = 0.0;
	$scope.description = ""; 
	
	$scope.calculate = function() {

		if($scope.peso !== '' && $scope.altura !== '') {
			//$scope.result = $scope.peso / ($scope.altura * $scope.altura);
			var url = [
				'http://bmi-soa.elasticbeanstalk.com/api/bmi',
				'/weight/', $scope.peso,
				'/height/',	$scope.altura,
				'/pt_br'
			].join("");

			$http.get(url)
			.success(function(data, status){
				$scope.result = data.bmi;
				$scope.description = data.description;
			})
			.error(function(data, status){
				console.log("Error: " + data);
			});
		}
			
	};

}